﻿user/user
admin/admin

http://comp229project.azurewebsites.net/